package tk.csparpa.gofdp.interpreter;

public interface AbstractExpression {

	public boolean interpret(Context context);
}
