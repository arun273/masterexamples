package tk.csparpa.gofdp.abstractfactory;

/**
 * 
 * Abstract interface for products of type Y
 *
 */
public interface AbstractProductY {
	
	public void feature();

}