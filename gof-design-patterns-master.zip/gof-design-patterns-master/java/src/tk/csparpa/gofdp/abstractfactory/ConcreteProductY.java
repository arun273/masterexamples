package tk.csparpa.gofdp.abstractfactory;

/**
 * 
 * Concrete implementation of AbstractProductTypeY
 *
 */
public class ConcreteProductY implements AbstractProductY {

	@Override
	public void feature() {
		System.out.println("Called: feature of concrete product Y");
	}
}