package tk.csparpa.gofdp.abstractfactory;

/**
 * 
 * Abstract interface for products of type X
 *
 */
public interface AbstractProductX {
	
	public void feature();

}
