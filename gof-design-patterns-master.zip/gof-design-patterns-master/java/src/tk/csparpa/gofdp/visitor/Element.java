package tk.csparpa.gofdp.visitor;

public interface Element {
	
	public void accept(Visitor visitor);
}
