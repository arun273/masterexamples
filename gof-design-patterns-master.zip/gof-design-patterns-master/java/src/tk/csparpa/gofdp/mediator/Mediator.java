package tk.csparpa.gofdp.mediator;

public interface Mediator {
	
	public void teamGreet();
	
	public void broadcastGreet();
}
