package tk.csparpa.gofdp.chainofresponsibility.variants;

import java.util.List;

public abstract class Request {
	
	public abstract List<String> getParameters();
}
