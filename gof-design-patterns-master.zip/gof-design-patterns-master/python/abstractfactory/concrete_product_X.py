from abstract_product_X import AbstractProductX

class ConcreteProductX(AbstractProductX):
    
    """
    Concrete implementation of AbstractProductTypeX
    """

    def feature(self):
        print("Called: feature of concrete product X")