GoF's original design patterns
==============================

Today baking in:

    Java, Python

flavours :-)
