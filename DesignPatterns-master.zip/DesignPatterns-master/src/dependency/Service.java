package dependency;

public interface Service {
	
	public String name();
}
