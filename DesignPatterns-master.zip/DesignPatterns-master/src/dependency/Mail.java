package dependency;

public class Mail implements Service{

	@Override
	public String name() {
		return "Mail";
	}
}
