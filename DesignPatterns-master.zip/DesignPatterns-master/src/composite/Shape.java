package composite;

public interface Shape {

	public void draw();
}
