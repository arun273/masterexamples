package factory.abstr;

public class Owl implements Animal{

	@Override
	public void display() {
		System.out.println("I'm the Owl");
	}

}
