package factory.abstr;

public class Fox implements Animal{

	@Override
	public void display() {
		System.out.println("I'm the Fox");		
	}

}
