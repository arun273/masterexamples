package factory.abstr;

public interface Animal {

	public void display();
}
