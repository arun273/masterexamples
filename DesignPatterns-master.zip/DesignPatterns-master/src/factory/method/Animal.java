package factory.method;

public interface Animal {

	public void voice();
}
