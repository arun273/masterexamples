package factory.method;

public class Cat implements Animal{

	@Override
	public void voice() {
		System.out.println("Meow");
	}

}
