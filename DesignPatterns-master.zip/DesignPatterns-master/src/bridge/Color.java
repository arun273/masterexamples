package bridge;

public interface Color {

	public void apply();
}
