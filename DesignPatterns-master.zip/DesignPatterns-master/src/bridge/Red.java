package bridge;

public class Red implements Color{

	@Override
	public void apply() {
		System.out.println("Red");
	}

}
