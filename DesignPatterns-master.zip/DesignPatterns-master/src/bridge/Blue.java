package bridge;

public class Blue implements Color{

	@Override
	public void apply() {
		System.out.println("Blue");
	}

}
