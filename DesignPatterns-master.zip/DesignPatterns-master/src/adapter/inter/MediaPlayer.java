package adapter.inter;

public interface MediaPlayer {

	public void play();
}
