package adapter.inter;

public interface MediaPackage {

	public void playFile();
}
