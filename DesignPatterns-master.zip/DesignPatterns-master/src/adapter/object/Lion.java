package adapter.object;

public class Lion implements Animal{

	@Override
	public void run() {
		System.out.println("Lion is running");
	}
}
