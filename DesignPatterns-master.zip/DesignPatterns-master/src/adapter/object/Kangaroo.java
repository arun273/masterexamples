package adapter.object;

public class Kangaroo {

	public void jump(){
		System.out.println("Kangaroo is jumping");
	}
}
