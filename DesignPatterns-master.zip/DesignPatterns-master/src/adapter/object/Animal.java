package adapter.object;

public interface Animal {

	public void run();

}
