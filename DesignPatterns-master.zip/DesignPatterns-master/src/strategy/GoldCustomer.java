package strategy;

public class GoldCustomer extends Customer{

	@Override
	public void display() {
		System.out.println("Hey! I am a GOLD Customer");
	}

}
