package strategy;

public interface Payment {

	public void make(int amount);
}
