package prototype.abstr;

public class Book extends Product{

	@Override
	public String toString() {
		return "Book";
	}
}
