package prototype.abstr;

public class Movie extends Product{

	@Override
	public String toString() {
		return "Movie";
	}
}
