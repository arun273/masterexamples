package prototype.abstr;

public class Album extends Product{

	@Override
	public String toString() {
		return "Album";
	}
}
