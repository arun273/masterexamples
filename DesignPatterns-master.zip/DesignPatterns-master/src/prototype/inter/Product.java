package prototype.inter;

public interface Product extends Cloneable{

	public Product clone();

}
