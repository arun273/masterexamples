/**
 * 抽象产品
 * Author: markliu
 * Time  : 16-8-28 上午9:21
 */
public interface ComboBox {
	void display();
}
