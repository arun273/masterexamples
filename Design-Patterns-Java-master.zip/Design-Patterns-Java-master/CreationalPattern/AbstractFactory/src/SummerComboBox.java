/**
 * Author: markliu
 * Time  : 16-8-28 上午9:26
 */
public class SummerComboBox implements ComboBox {
	@Override
	public void display() {
		System.out.println("display Summer ComboBox");
	}
}
