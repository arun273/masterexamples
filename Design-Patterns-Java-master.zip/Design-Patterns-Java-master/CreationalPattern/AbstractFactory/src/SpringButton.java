/**
 * Author: markliu
 * Time  : 16-8-28 上午9:25
 */
public class SpringButton implements Button {
	@Override
	public void display() {
		System.out.println("display Spring Button");
	}
}
