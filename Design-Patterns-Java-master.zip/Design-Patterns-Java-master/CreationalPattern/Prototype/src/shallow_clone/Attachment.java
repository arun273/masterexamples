package shallow_clone;

/**
 * Author: markliu
 * Time  : 16-8-28 下午1:22
 */
public class Attachment {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
