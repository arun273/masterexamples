/**
 * Author: markliu
 * Time  : 16-8-27 下午9:32
 */
public class PieChart implements Chart {

	public PieChart() {
		System.out.println("create PieChart");
	}

	@Override
	public void display() {
		System.out.println("display PieChart");
	}
}
