/**
 * 抽象产品类
 * Author: markliu
 * Time  : 16-8-27 下午9:27
 */
public interface Chart {

	void display();
}
