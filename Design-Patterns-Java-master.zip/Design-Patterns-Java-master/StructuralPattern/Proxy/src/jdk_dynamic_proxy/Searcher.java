package jdk_dynamic_proxy;

/**
 * Author: markliu
 * Time  : 16-9-2 下午4:25
 */
public interface Searcher {

	String doSearch(String userId, String keywords);
}
