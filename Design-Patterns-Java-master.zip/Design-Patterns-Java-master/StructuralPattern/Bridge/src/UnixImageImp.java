/**
 * Author: markliu
 * Time  : 16-8-31 上午1:39
 */
public class UnixImageImp implements ImageImp {

	@Override
	public void doPaint() {
		System.out.println("Unix OS doPaint JPGImage");
	}
}
