/**
 * Author: markliu
 * Time  : 16-8-31 上午1:39
 */
public class WindowsImageImp implements ImageImp {

	@Override
	public void doPaint() {
		System.out.println("Windows OS doPaint JPGImage");
	}
}
