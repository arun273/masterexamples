/**
 * 抽象实现化角色，一般定义操作简单的业务
 * Author: markliu
 * Time  : 16-8-31 上午1:31
 */
public interface ImageImp {

	void doPaint();
}
