/**
 * SubSystem（子系统角色）
 *
 * Author: markliu
 * Time  : 16-8-31 下午6:17
 */
public class FileReader {

	public String read(String fileName) {
		String readText = "read file: " + fileName;
		System.out.println(readText);
		return readText;
	}
}
