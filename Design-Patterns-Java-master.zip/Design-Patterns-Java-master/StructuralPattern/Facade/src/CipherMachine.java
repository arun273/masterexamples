/**
 * SubSystem（子系统角色）
 *
 * Author: markliu
 * Time  : 16-8-31 下午6:17
 */
public class CipherMachine {

	public String encrypt(String plainText) {
		String encrypt = "encrypt text:" + plainText;
		System.out.println(encrypt);
		return encrypt;
	}
}
