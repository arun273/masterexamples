/**
 * SubSystem（子系统角色）
 *
 * Author: markliu
 * Time  : 16-8-31 下午6:17
 */
public class FileWriter {

	public void write(String encryptText, String filenameDes) {
		System.out.println("write encryptText " + encryptText + " to file: " + filenameDes);
	}
}
