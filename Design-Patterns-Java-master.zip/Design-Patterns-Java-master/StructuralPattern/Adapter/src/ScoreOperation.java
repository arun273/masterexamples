/**
 * 目标接口，客户端需要操作的接口
 * Author: markliu
 * Time  : 16-8-28 下午5:25
 */
public interface ScoreOperation {

	int[] sort(int array[]);

	int search(int array[], int key);
}
