/**
 * Author: markliu
 * Time  : 16-8-28 下午5:31
 */
public class BinarySearch {

	public int binarySearch(int array[], int key) {
		System.out.println("调用适配者 BinarySearch 的 binarySearch 方法");

		// 二分搜索算法
		return key;
	}
}
