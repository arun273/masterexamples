/**
 * Author: markliu
 * Time  : 16-9-4 下午3:26
 */
public class TextBox extends Component {

	@Override
	public void update(Component component) {
		System.out.println(component + " 触发 TextBox update");
	}
}
