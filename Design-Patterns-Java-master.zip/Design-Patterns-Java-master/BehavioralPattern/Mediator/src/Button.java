/**
 * Author: markliu
 * Time  : 16-9-4 下午3:26
 */
public class Button extends Component {

	@Override
	public void update(Component component) {
		System.out.println(component + " 触发 Button update");
	}
}
