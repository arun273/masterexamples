/**
 * Author: markliu
 * Time  : 16-9-4 下午3:36
 */
public class ComboBox extends Component {

	@Override
	public void update(Component component) {
		System.out.println(component + " 触发 ComboBox update");
	}
}
