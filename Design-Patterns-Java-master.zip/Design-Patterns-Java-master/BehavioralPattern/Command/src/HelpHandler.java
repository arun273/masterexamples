/**
 * 接收者：接收者执行与请求相关的操作，它具体实现对请求的业务处理。
 *
 * Author: markliu
 * Time  : 16-9-4 上午11:55
 */
public class HelpHandler {

	public void help() {
		System.out.println("display help");
	}
}
