/**
 * Author: markliu
 * Time  : 16-9-2 下午10:19
 */
public class PurchaseRequest {

	private double amount;

	public PurchaseRequest(double amount) {
		this.amount = amount;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
}
