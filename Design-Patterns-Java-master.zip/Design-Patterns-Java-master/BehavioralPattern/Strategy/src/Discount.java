/**
 * Author: markliu
 * Time  : 16-9-3 下午3:20
 */
public interface Discount {

	double calculate(double price);
}
