/**
 * Author: markliu
 * Time  : 16-9-8 下午7:25
 */
public interface Employee {

	void accept(Department handler); //接受一个抽象访问者访问

}
