/**
 * Author: markliu
 * Time  : 16-9-3 下午4:42
 */
public class CurrentAccount extends Account {

	@Override
	public void calculateInterest() {
		System.out.println("CurrentAccount calculateInterest");
	}
}
